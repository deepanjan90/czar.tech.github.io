$(document).ready(function () {
	$('#buttonMap').click(function () {
		window.location.href="citystatus.html";

		/*$.ajax({
  type: "GET",
  url: "http://localhost:5000/"
}).done(function( o ) {
   // do something
   console.log(o);
});
	});*/

	/*$.ajax({
  type: "POST",
  url: "http://localhost:5000/data",
  contentType: "application/json; charset=utf-8",
  data: '{"lat":"5.0","lon":"5.0"}'
}).done(function( o ) {
   // do something
   console.log(o);
});
	});*/
});